import{c as t,j as e,m as i}from"./createLucideIcon.G7Gzbalp.js";import{M as o}from"./monitor.vTGaSpqs.js";import"./index.Cd_vQiNd.js";/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M17 20v2",key:"1rnc9c"}],["path",{d:"M17 2v2",key:"11trls"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M2 17h2",key:"7oei6x"}],["path",{d:"M2 7h2",key:"asdhe0"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"M20 17h2",key:"1fpfkl"}],["path",{d:"M20 7h2",key:"1o8tra"}],["path",{d:"M7 20v2",key:"4gnj0m"}],["path",{d:"M7 2v2",key:"1i4yhu"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2",key:"1vbyd7"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1",key:"z9xiuo"}]],l=t("cpu",r);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],c=t("database",d);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],p=t("globe",n);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]],x=t("panels-top-left",h);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],u=t("shield",m),y=[{icon:e.jsx(p,{className:"w-8 h-8"}),title:"Desarrollo Web a Medida",description:"Creación de sitios web únicos, rápidos y optimizados para SEO utilizando las últimas tecnologías."},{icon:e.jsx(o,{className:"w-8 h-8"}),title:"Sistemas Web Corporativos",description:"Plataformas de gestión, ERPs y CRMs personalizados para optimizar los procesos de tu empresa."},{icon:e.jsx(l,{className:"w-8 h-8"}),title:"Software de Escritorio",description:"Aplicaciones nativas para Windows desarrolladas en Python, potentes y eficientes."},{icon:e.jsx(x,{className:"w-8 h-8"}),title:"Diseño UI/UX",description:"Interfaces intuitivas y atractivas que mejoran la experiencia de tus usuarios."},{icon:e.jsx(c,{className:"w-8 h-8"}),title:"Integración de APIs",description:"Conectamos tus sistemas con servicios de terceros para automatizar flujos de trabajo."},{icon:e.jsx(u,{className:"w-8 h-8"}),title:"Ciberseguridad Básica",description:"Implementación de buenas prácticas para proteger tus aplicaciones y datos."}];function v(){return e.jsx("section",{id:"services",className:"py-24 bg-slate-50 dark:bg-[#0f0f0f] relative overflow-hidden",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10",children:[e.jsxs("div",{className:"text-center mb-16",children:[e.jsx("h2",{className:"text-3xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4",children:"Nuestros Servicios"}),e.jsx("p",{className:"text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto",children:"Soluciones tecnológicas integrales diseñadas para impulsar el crecimiento de tu negocio."})]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",children:y.map((a,s)=>e.jsxs(i.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:s*.1},className:"group p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-all hover:shadow-2xl hover:shadow-blue-500/10 relative overflow-hidden",children:[e.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-bl-full -mr-16 -mt-16 transition-transform group-hover:scale-150"}),e.jsx("div",{className:"w-14 h-14 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300",children:a.icon}),e.jsx("h3",{className:"text-xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors",children:a.title}),e.jsx("p",{className:"text-slate-600 dark:text-slate-400 leading-relaxed",children:a.description})]},s))})]})})}export{v as default};
